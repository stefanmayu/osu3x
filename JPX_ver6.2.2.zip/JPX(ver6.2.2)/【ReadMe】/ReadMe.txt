1. Set the software to JPX.exe, please do not run JPX.exe separately from the folder. 

2.  Recommended reading for 'Beginner's Guide'